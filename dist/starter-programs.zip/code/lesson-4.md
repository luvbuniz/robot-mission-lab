# Mission 4: Crack the color code

LEGO Education #45522 · Coding Canvas word-block recipe

This is a human-readable programming recipe, not an importable LEGO project. The teacher maps it to the current block palette, saves the project and verifies it on the actual kit before class.

1. START → stop movement
2. REPEAT 10 times: show the sensor’s reported color; wait 0.2 seconds
3. STOP; end. Repeat for each sample and log all readings

## Teacher checks

Use only the intended team hardware. Verify low-speed direction, bounded duration, on-screen stop and hardware power-off. Test stationary sensing before movement. Red and unknown must end the approach trial. A grid simulation does not validate the physical build.

## Build resources

Official #45522 instructions: https://www.lego.com/service/buildinginstructions/45522
Coding Canvas: https://code.legoeducation.com/
Teacher Portal: https://teach.legoeducation.com/
